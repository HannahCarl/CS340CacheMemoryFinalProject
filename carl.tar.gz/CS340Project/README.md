# CS340CacheMemoryFinalProject

# Team Members

Jacob Mattox - https://github.com/jacobmattox

Hannah Carl - https://github.com/PoschH

# Requirements

Our team will be seeking to discover through experimentation answers to the four questions listed below:

    1. How big is a cache block?
    2. How big is the cache?
    3. How long does a reference to main memory take to complete?
    4. How long does a reference that can be satisfied from cache take to complete?
    
# Files

1. Makefile
2. cache.H
3. cache.c
4. README.md
5. README.txt
